        <!-- Menu -->
        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
            <div class="app-brand demo">
                <a href="" class="app-brand-link">
                    <div class="icon p-2 me-2">
                        <img class="" src="<?php echo e(asset('img/group12.svg')); ?>" alt="Icon"
                            style="width: 40px; height: 40px;">
                    </div>
                    <span class=" menu-text fw-bolder ms-2">E-Reserve</span>
                </a>

                <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                    <i class="bx bx-chevron-left bx-sm align-middle"></i>
                </a>
            </div>

            <div class="menu-inner-shadow"></div>

            <ul class="menu-inner py-1">
                <!-- Dashboard -->
                <li class="menu-item <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/dashboard')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-home-circle"></i>
                        <div data-i18n="Analytics">Dashboard</div>
                    </a>
                </li>

                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Homestay</span>
                </li>
                <li class="menu-item <?php echo e(request()->is('datahomestay', 'tambahhomestay') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon tf-icons bx bx-dock-top"></i>
                        <div data-i18n=" ">Homestay</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item">
                            <a href="<?php echo e(url('/datahomestay')); ?>" class="menu-link">
                                <div data-i18n="">Data Homestay</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(url('/tambahhomestay')); ?>" class="menu-link">
                                <div data-i18n="">Tambah Homestay</div>
                            </a>
                        </li>
                    </ul>
                </li>
                

                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Fasilitas</span>
                </li>
                <li class="menu-item <?php echo e(request()->is('datafasilitas', 'tambahfasilitas') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon tf-icons bx bx-dock-top"></i>
                        <div data-i18n=" ">Fasilitas Homestay</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item">
                            <a href="<?php echo e(url('/datafasilitas')); ?>" class="menu-link">
                                <div data-i18n="">Data Fasilitas</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(url('/tambahfasilitas')); ?>" class="menu-link">
                                <div data-i18n="">Tambah Fasilitas</div>
                            </a>
                        </li>
                    </ul>
                </li>
                

                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Paket Wisata</span>
                </li>
                <li class="menu-item <?php echo e(request()->is('datapaketwisata', 'tambahpaketwisata') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon tf-icons bx bx-dock-top"></i>
                        <div data-i18n=" ">Paket Wisata</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item">
                            <a href="<?php echo e(url('/datapaketwisata')); ?>" class="menu-link">
                                <div data-i18n="">Data Wisata</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(url('/tambahpaketwisata')); ?>" class="menu-link">
                                <div data-i18n="">Tambah Wisata</div>
                            </a>
                        </li>
                    </ul>
                </li>
                

                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Transaksi</span>
                </li>
                <li
                    class="menu-item <?php echo e(request()->is('transaksi', 'transaksi/pengeluaran', 'transaksi/wisata', 'transaksi/layanan') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon tf-icons bx bx-dock-top"></i>
                        <div data-i18n="">Transaksi</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item">
                            <a href="/transaksi" class="menu-link">
                                <div data-i18n="">Data Transaksi</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/transaksi/history" class="menu-link">
                                <div data-i18n="">History Transaksi</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/transaksi/wisata" class="menu-link">
                                <div data-i18n="">Wisata Transaksi</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/transaksi/layanan" class="menu-link">
                                <div data-i18n="">Layanan Transaksi</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="/transaksi/pengeluaran" class="menu-link">
                                <div data-i18n="">Data Pengeluaran</div>
                            </a>
                        </li>
                    </ul>
                </li>
                

                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Pemilik Homestay</span>
                </li>
                <li class="menu-item <?php echo e(request()->is('datapemilikhomestay') ? 'active' : ''); ?>">
                    <a href="" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-collection"></i>
                        <div data-i18n="Basic">Data Pemilik Homestay</div>
                    </a>
                </li>
                

                
                
                


                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Artikel</span>
                </li>
                <li class="menu-item <?php echo e(request()->is('dataartikel', 'tambahartikel') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon tf-icons bx bx-dock-top"></i>
                        <div data-i18n="">Artikel</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item">
                            <a href="<?php echo e(url('/dataartikel')); ?>" class="menu-link">
                                <div data-i18n="">Data Artikel</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(url('/tambahartikel')); ?>" class="menu-link">
                                <div data-i18n="">Tambah Artikel</div>
                            </a>
                        </li>
                    </ul>
                </li>
                

                
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Layanan Tambahan</span>
                </li>
                <li class="menu-item <?php echo e(request()->is('datalayanan', 'tambahlayanan') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon tf-icons bx bx-dock-top"></i>
                        <div data-i18n="">Layanan Tambahan</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item">
                            <a href="<?php echo e(url('/datalayanan')); ?>" class="menu-link">
                                <div data-i18n="">Data Layanan</div>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(url('/tambahlayanan')); ?>" class="menu-link">
                                <div data-i18n="">Tambah Layanan</div>
                            </a>
                        </li>

                    </ul>
                </li>
                
            </ul>
        </aside>
        <!-- / Menu -->
<?php /**PATH /Users/mytelumobile/Downloads/kamojang/Aplikasi-E-Reserve/resources/views/layouts/admin/asidebar.blade.php ENDPATH**/ ?>