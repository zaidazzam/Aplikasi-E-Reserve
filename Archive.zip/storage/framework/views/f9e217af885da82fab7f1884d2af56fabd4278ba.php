
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Homestay /</span> Data Homestay</h4>
    <!-- Bordered Table -->
    <div class="card">
        <h5 class="card-header">Tabel Data Homestay</h5>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered mb-4">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Pemilik</th>
                            <th>Harga</th>
                            <th>Kamar</th>
                            <th>Tamu</th>
                            <th>Alamat</th>
                            <th>latitude</th>
                            <th>longitude</th>
                            <th>Gambar</th>
                            <th>Deskripsi</th>
                            <th>Fasilitas</th>
                            <th>Kebijakan</th>
                            <th>Status</th>
                            <th>Ubah</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $homestay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekomendasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>ID</td>
                                <td><?php echo e($rekomendasi->nama); ?></td>
                                <td><?php echo e($rekomendasi->users_id); ?></td>
                                <td><?php echo e($rekomendasi->harga); ?></td>
                                <td><?php echo e($rekomendasi->jumlah_kamar); ?></td>
                                <td><?php echo e($rekomendasi->kapasitas_kamar); ?></td>
                                <td><?php echo e($rekomendasi->alamat); ?></td>
                                <td><?php echo e($rekomendasi->latitude); ?></td>
                                <td><?php echo e($rekomendasi->longitude); ?></td>
                                <td class="text-wrap">
                                    <a href="<?php echo e(route('homestays.image', ['homestays' => $rekomendasi->id])); ?>"> <button
                                            class="btn btn-outline-primary" type="button"
                                            id="button-addon1">Gambar</button></a>
                                </td>
                                <td><?php echo e($rekomendasi->deskripsi); ?></td>
                                <td class="text-wrap">
                                    <a href="<?php echo e(url('/tambahhomestay/fasilitas/')); ?>"> <button
                                            class="btn btn-outline-primary" type="button" id="button-addon1">
                                            Fasilitas</button></a>
                                </td>
                                <td><?php echo e($rekomendasi->kebijakan); ?></td>
                                <td><span class="badge bg-label-primary me-1">Rekomendasi</span></td>
                                <td>Ubah</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>

                <?php echo e($homestay->links()); ?>

            </div>
        </div>
    </div>
    <!--/ Bordered Table -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/mytelumobile/Downloads/kamojang/Aplikasi-E-Reserve/resources/views/admin/homestay/data-homestay.blade.php ENDPATH**/ ?>