<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Homestay /Data Homestay /Gambar/</span> Homestay
        Garden</h4>
    <!-- Bordered Table -->
    <div class="card">
        <h5 class="card-header">Gambar Homestay</h5>
        <div class="row justify-content-start px-4">
            <div class="col-sm-10">
                <!-- Large Modal -->
                <div class="modal fade" id="addHomestayButton" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel3">Tambah Gambar</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="imageForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label for="label_file" class="form-label">Upload Gambar</label>
                                            <input class="form-control" type="file" placeholder="Pilih gambar" id="label_file" name="image" multiple />
                                            <input type="number" class="form-control" style = "display:none"
                                                        value="<?php echo e($homestay->id); ?>"
                                                        id = "homestay_id"
                                                        name="homestay_id" placeholder="Nama depan">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                    Tutup
                                </button>
                                <button type="button" id="addHomestay" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addHomestayButton">
                    Tambah Gambar
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th class="text-center">Gambar</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $image_homestay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekomendasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                <td> <img class="img-fluid-gambar" src="<?php echo e(asset('storage/' . $rekomendasi->image)); ?>"
                                        alt="">
                                </td>
                                <td class="text-center"> <button type="submit" class="btn btn-danger">Hapus</button>
                                </td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!--/ Bordered Table -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<style>
    .img-fluid-gambar {
        width: 15%;
        height: auto;
    }
</style>
<?php /**PATH /Users/mytelumobile/Downloads/kamojang/Aplikasi-E-Reserve/resources/views/admin/homestay/tambah-gambar-homestay.blade.php ENDPATH**/ ?>