<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Rekomendasi</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('homestays.update', $rekomendasi)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
    <label for="nama">Nama Homestay:</label>
    <input type="text" name="nama" id="nama" class="form-control" required value="<?php echo e(old('nama', $rekomendasi->nama)); ?>">
</div>

<div class="form-group">
    <label for="image">Image:</label>
    <input type="file" name="image" id="image" class="form-control-file" accept="image/*">
</div>

<div class="form-group">
    <img id="image-preview" src="#" alt="Preview" style="display: none; max-width: 100%;">
</div>

<div class="form-group">
    <label for="harga">Harga:</label>
    <input type="number" name="harga" id="harga" class="form-control" required value="<?php echo e(old('harga', $rekomendasi->harga)); ?>">
</div>

<div class="form-group">
    <label for="alamat">Alamat:</label>
    <textarea name="alamat" id="alamat" class="form-control" rows="3" required><?php echo e(old('alamat', $rekomendasi->alamat)); ?></textarea>
</div>

<div class="form-group">
    <label for="latitude">Latitude:</label>
    <input type="number" name="latitude" id="latitude" class="form-control" required value="<?php echo e(old('latitude', $rekomendasi->latitude)); ?>">
</div>

<div class="form-group">
    <label for="longitude">Longitude:</label>
    <input type="number" name="longitude" id="longitude" class="form-control" required value="<?php echo e(old('longitude', $rekomendasi->longitude)); ?>">
</div>

<div class="form-group">
    <label for="deskripsi">Deskripsi:</label>
    <textarea name="deskripsi" id="deskripsi" class="form-control" rows="5" required><?php echo e(old('deskripsi', $rekomendasi->deskripsi)); ?></textarea>
</div>

<div class="form-group">
    <label for="kebijakan">Kebijakan:</label>
    <textarea name="kebijakan" id="kebijakan" class="form-control" rows="5" required><?php echo e(old('kebijakan', $rekomendasi->kebijakan)); ?></textarea>
</div>

<div class="form-group">
    <label for="jumlah_kamar">Jumlah Kamar:</label>
    <input type="number" name="jumlah_kamar" id="jumlah_kamar" class="form-control" required value="<?php echo e(old('jumlah_kamar', $rekomendasi->jumlah_kamar)); ?>">
</div>

<div class="form-group">
    <label for="kapasitas_kamar">Kapasitas Kamar:</label>
    <input type="text" name="kapasitas_kamar" id="kapasitas_kamar" class="form-control" required value="<?php echo e(old('kapasitas_kamar', $rekomendasi->kapasitas_kamar)); ?>">
</div>



                        <!-- Add fields for other attributes -->

                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/mytelumobile/Downloads/kamojang/Aplikasi-E-Reserve/resources/views/admin/homestay/edit-homestay.blade.php ENDPATH**/ ?>